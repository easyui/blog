//
//  BaseClass.h
//  testLoadInitialize
//
//  Created by yangjun zhu on 15/5/4.
//  Copyright (c) 2015年 ouka. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface BaseClass : NSObject

@end
