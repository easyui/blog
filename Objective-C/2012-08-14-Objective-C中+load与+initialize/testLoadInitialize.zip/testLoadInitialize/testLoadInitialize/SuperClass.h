//
//  SuperClass.h
//  testLoadInitialize
//
//  Created by yangjun zhu on 15/5/4.
//  Copyright (c) 2015年 ouka. All rights reserved.
//

#import "BaseClass.h"

@interface SuperClass : BaseClass

@end
