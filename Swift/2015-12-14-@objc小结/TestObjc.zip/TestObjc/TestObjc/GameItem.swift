//
//  GameItem.swift
//  TestObjc
//
//  Created by yangjun zhu on 15/12/9.
//  Copyright © 2015年 Cactus. All rights reserved.
//

import Foundation

@objc(GameSwfitItem)
class GameItem:NSObject{
    @objc(swiftName)
    var name: String
    
    @objc(initSwift:)
    init(name:String){
        self.name = name
    }
    
    
    ///Users/yangjunzhu/Downloads/TestObjc/TestObjc/VideoItem.swift:12:2: Only classes that inherit from NSObject can be declared @objc
    
}