//
//  MyClassDelegate.swift
//  TestObjc
//
//  Created by yangjun zhu on 15/12/14.
//  Copyright © 2015年 Cactus. All rights reserved.
//

import Foundation
protocol MyClassDelegate:class{
    func methold1()
}