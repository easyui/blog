//
//  OptionalProocol.swift
//  TestObjc
//
//  Created by yangjun zhu on 15/12/14.
//  Copyright © 2015年 Cactus. All rights reserved.
//

import Foundation



@objc protocol OptionalProtocol{
    @objc optional func optionalMethold1()
    @objc optional func optionalMethold2()
    func requestMethold1()
}
