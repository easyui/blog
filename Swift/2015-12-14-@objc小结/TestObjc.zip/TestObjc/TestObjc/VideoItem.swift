//
//  VideoItem.swift
//  TestObjc
//
//  Created by yangjun zhu on 15/12/9.
//  Copyright © 2015年 Cactus. All rights reserved.
//

import Foundation


class VideoItem:NSObject,MyClassDelegate{
    weak var delegate:MyClassDelegate?
//    /Users/yangjunzhu/Downloads/TestObjc/TestObjc/VideoItem.swift:13:14: 'weak' cannot be applied to non-class type 'MyClassDelegate'
    var name: String
    
    init(name:String){
        self.name = name
    }


    func sayHello(){
      print("\(__FUNCTION__)")
    }
    
   @objc private func privateSayHello(){
        print("\(__FUNCTION__)")
    }
    
    func methold1() {
        print("\(__FUNCTION__)")
    }
    
    
///Users/cactus/Downloads/TestObjc/TestObjc/VideoItem.swift:12:2: Only classes that inherit from NSObject can be declared @objc

    
}