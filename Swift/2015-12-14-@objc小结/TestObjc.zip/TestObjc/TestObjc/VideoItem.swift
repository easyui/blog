//
//  VideoItem.swift
//  TestObjc
//
//  Created by yangjun zhu on 15/12/9.
//  Copyright © 2015年 Cactus. All rights reserved.
//

import Foundation


class VideoItem:NSObject,MyClassDelegate{
    weak var delegate:MyClassDelegate?
//    /Users/yangjunzhu/Downloads/TestObjc/TestObjc/VideoItem.swift:13:14: 'weak' cannot be applied to non-class type 'MyClassDelegate'
    @objc var name: String
    
    @objc init(name:String){
        self.name = name
    }


   @objc func sayHello(){
        print("\(#function)")
    }
    
   @objc private func privateSayHello(){
        print("\(#function)")
    }
    
    func methold1() {
        print("\(#function)")
    }
    
    
///Users/cactus/Downloads/TestObjc/TestObjc/VideoItem.swift:12:2: Only classes that inherit from NSObject can be declared @objc

    
}
