//
//  ViewController.m
//  TestObjc
//
//  Created by yangjun zhu on 15/12/9.
//  Copyright © 2015年 Cactus. All rights reserved.
//

#import "ViewController.h"
#import "TestObjc-Swift.h"

@interface ViewController () <OptionalProtocol>

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
   VideoItem *video = [[VideoItem alloc] initWithName:@"007v"];
    NSLog(@"%@",video.name);
    [video performSelector:@selector(sayHello)];
    [video performSelector:@selector(privateSayHello)];

    
    GameSwfitItem *game = [[GameSwfitItem alloc] initSwift:@"007g"];
      NSLog(@"%@",game.swiftName);
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)optionalMethold1{
    NSLog(@"\(__FUNCTION__)");

}


-(void)requestMethold1{
    NSLog(@"\(__FUNCTION__)");
}

@end
