# JPPictureInPictureDemo

## PictureInPictureDemo of iOS14.

[Detailed description in blog](https://juejin.im/post/5ef9bc7d5188252e3426c0d2)

## Author

Email: zhoujianping24@hotmail.com, Blog: https://www.jianshu.com/u/2edfbadd451c
