//
//  YJAppDelegate.h
//  textfield
//
//  Created by NeuLion SH on 13-3-28.
//  Copyright (c) 2013年 yangjun. All rights reserved.
//

#import <UIKit/UIKit.h>

@class YJViewController;

@interface YJAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) YJViewController *viewController;

@end
