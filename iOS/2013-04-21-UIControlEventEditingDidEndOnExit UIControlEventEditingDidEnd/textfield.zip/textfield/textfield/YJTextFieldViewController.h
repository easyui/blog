//
//  YJTextFieldViewController.h
//  textfield
//
//  Created by NeuLion SH on 13-3-28.
//  Copyright (c) 2013年 yangjun. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface YJTextFieldViewController : UIViewController<UITextFieldDelegate>
@property (strong, nonatomic) IBOutlet UITextField *textField1;
@property (strong, nonatomic) IBOutlet UITextField *textField2;
- (IBAction)backTap:(id)sender;
- (IBAction)textField1ButtonTap:(id)sender;
- (IBAction)textField2ButtonTap:(id)sender;
- (IBAction)textFieldallButtonTap:(id)sender;

@end
