//
//  YJTextFieldViewController.m
//  textfield
//
//  Created by NeuLion SH on 13-3-28.
//  Copyright (c) 2013年 yangjun. All rights reserved.
//

#import "YJTextFieldViewController.h"

@interface YJTextFieldViewController ()

@end

@implementation YJTextFieldViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.textField1.delegate = self;
    self.textField2.delegate = self;
    // Do any additional setup after loading the view from its nib.
    [self.textField1 addTarget:self
                  action:@selector(textFieldDone:)
        forControlEvents:UIControlEventEditingDidEndOnExit];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)backTap:(id)sender {
    NSLog(@"backTap1");
    [self dismissViewControllerAnimated:YES completion:nil];
    NSLog(@"backTap2");
}

- (IBAction)textField1ButtonTap:(id)sender {
    [self.textField1 resignFirstResponder];
}

- (IBAction)textField2ButtonTap:(id)sender {
    [self.textField2 resignFirstResponder];
    [self.textField1 becomeFirstResponder];
}

- (IBAction)textFieldallButtonTap:(id)sender {
    [self.textField1 resignFirstResponder];
    [self.textField2 resignFirstResponder];
}

- (IBAction)textFieldDone:(id)sender {
    NSLog(@"textFieldDone");
}


-(void)textFieldDidEndEditing:(UITextField *)textField{
    NSLog(@"textFieldDidEndEditing");
}



//- (BOOL)textFieldShouldReturn:(UITextField *)textField{
// NSLog(@"textFieldShouldReturn");
////    return YES;
//    return NO;
//
//}
@end
