//
//  YJViewController.h
//  textfield
//
//  Created by NeuLion SH on 13-3-28.
//  Copyright (c) 2013年 yangjun. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YJTextFieldViewController.h"
@interface YJViewController : UIViewController

- (IBAction)buttonTap:(id)sender;

@end
