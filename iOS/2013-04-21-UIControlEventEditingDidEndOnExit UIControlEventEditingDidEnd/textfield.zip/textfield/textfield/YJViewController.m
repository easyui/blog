//
//  YJViewController.m
//  textfield
//
//  Created by NeuLion SH on 13-3-28.
//  Copyright (c) 2013年 yangjun. All rights reserved.
//

#import "YJViewController.h"

@interface YJViewController ()

@end

@implementation YJViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)buttonTap:(id)sender {
    YJTextFieldViewController *recordViewController = [[YJTextFieldViewController alloc] initWithNibName:@"YJTextFieldViewController" bundle:nil];
    recordViewController.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
      [self presentViewController:recordViewController animated:YES completion:nil];
}
@end
