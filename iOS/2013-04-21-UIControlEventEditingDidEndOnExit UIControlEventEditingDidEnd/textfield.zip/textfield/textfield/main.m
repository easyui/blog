//
//  main.m
//  textfield
//
//  Created by NeuLion SH on 13-3-28.
//  Copyright (c) 2013年 yangjun. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "YJAppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([YJAppDelegate class]));
    }
}
