//
//  ContentView.swift
//  swiftuihello
//
//  Created by ouka on 2020/3/22.
//  Copyright © 2020 Yangjun Zhu. All rights reserved.
//

import SwiftUI

struct ContentView: View {

    var body: some View {
        Group{
        Text("1").onAppear {
            printLog("1")
        }
        Text("2").onAppear {
                   printLog("2")
        }
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}
