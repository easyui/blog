//
//  ViewController.swift
//  swiftvchello
//
//  Created by ouka on 2020/3/22.
//  Copyright © 2020 Yangjun Zhu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    deinit {
        printLog()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        //        UITableView
        // Do any additional setup after loading the view.
        printLog()
        
    }
    
    override func viewWillLayoutSubviews() {
        super.viewWillLayoutSubviews()
        printLog()
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        printLog()
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        printLog()
        
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        printLog()
        
    }
    
    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        printLog()
        
        
    }
    
    override func viewDidDisappear(_ animated: Bool) {
        super.viewDidDisappear(animated)
        printLog()
        
        
    }
    
    
}

