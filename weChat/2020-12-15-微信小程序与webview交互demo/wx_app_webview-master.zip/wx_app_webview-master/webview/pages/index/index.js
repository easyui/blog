//index.js
//获取应用实例
const app = getApp();

Page({
  data: {
    visitUrl: "",
  },
  onLoad: function() {
    this.setData({
      visitUrl: "http://10.5.178.7:8000/webview.html#/hash",
    });
  },
});