// pages/webview/webview.js
/*
接受的参数:
h5Url:页面的url
pageType:页面类型，h5Url的优先级高于pageType

target:{

}
*/
Page({

  /**
   * 页面的初始数据
   */
  data: {
    h5Url:undefined,
    pageType:undefined
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      h5Url: options.h5Url
    })
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    console.log("cactus onUnload")

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },


  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    console.log("cactus onShareAppMessage")

  },

  bindmessage(e) {
    console.log("cactus bindmessage")

    console.log(e.detail)
    this.setData({
      shareContent: e.detail
    })
    console.log("【从h5传到小程序的内容：】")
    console.log(this.data.shareContent.data[0])
    let _h5Url = this.data.h5Url + '#ShareOk'
    this.setData({
      h5Url: _h5Url
    })
  },
})